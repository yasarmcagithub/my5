<?php 

echo $_POST['searchinfo'];

 ?>