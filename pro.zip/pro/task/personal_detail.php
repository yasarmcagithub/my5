<?php require_once('conn.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add Details</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	
	<style type="text/css">
		label
		{
			display: inline-block;
			width: 250px;
		}
		div
		{
			margin-top: 10px;
		}
		.center
		{
            display: flex;
			margin: 0 auto;
			justify-content: center;
			align-items: center;
			max-width: 100%;
		}
		.btn
		{
			text-align: center;
			margin-top: 10px;
		}
		input,select,textarea
		{
		   outline: none;
		}
		.error
		{
			   display:block;
			   margin-top: 10px;
			   color: red;
			   display: none;
			 
		}
        select
		{
			width: 100px;
		}
		#success        /*  //from the postdata*/
		{
			text-align: center;
			color: green;
			font-size: 20px;

		}


	</style>
</head>
<body>
	<div class="center">
		<form method="post" _onsubmit="return (validate());" id="form" _action="postdata.php">
			<h1>Personal Details</h1>
				<?php
					$id       =$_GET['id'];
			        $query="SELECT * FROM personal_detail Where id=$id";
			        $run=mysqli_query($conn,$query);
			        foreach ($run as $row) {
			     ?>
			<div>
				<label>First Name</label>
				<input type="text" name="fname" id="fname" value="<?php echo $row['first_name'];?>">
				<span class="error" id="err_fname" >Please Fill the Feild</span>
				<span class="error" id="err_fname_check" >Please Enter Valid First Name </span>
			</div>
			<div>
				<label>Last Name</label>
				<input type="text" name="lname" id="lname" value="<?php echo $row['last_name']; ?>">
				<span class="error" id="err_lname">Please Fill the Feild</span>
				<span class="error" id="err_lname_check" >Please Enter Valid Last Name </span>
			</div>
			<div>
				<label>Email</label>
				<input type="text" name="email" id="email" value="<?php echo $row['email']; ?>">
				<span class="error" id="err_email">Please Fill the Feild</span>
				<span class="error" id="err_email_exist">Please Fill the Feild</span>
				<span class="error" id="pattern_err_email">Please Fill the Feild</span>
			</div>
			<div>
				
				<label>Gender</label>
				<span>Male</span><input type="radio" name="gender" <?php echo($row['gender']==1 ? 'checked': '' );?> value="1" id="male" >
				<span>Female</span><input type="radio" name="gender" <?php echo($row['gender']==2 ? 'checked': '' );?> value="2" id="female">
				<span class="error" id="err_gender">Please Fill the Feild</span>
			</div>
			<div>
				<label>Mobile Number</label>
				<input type="text" name="mobile_no" id="mobile_no" value="<?php echo $row['mobile_no']; ?>">
				<span class="error" id="#err_mobile_no">Please Fill the Feild</span>
				<span class="error" id="#err_mobile_no_check">Please Enter Valid mobile Number</span>
			</div>
			<div>
				<label>Addres 1</label>
				<textarea name="addr1" id="addr1"><?php echo $row['addr1']; ?></textarea>
				<span class="error" id="err_addr1">Please Fill the Feild</span>
			</div>
				<div>
				<label>Addres 2</label>
				<textarea name="addr2" id="addr2"><?php echo $row['addr2']; ?></textarea>
				<span class="error" id="err_addr2">Please Fill the Feild</span>
			</div>
			
			<div>
				<label>Country</label>
				<select name="country" id="country">
			       <option value="select">Select</option>
			       <?php
			     $sql="SELECT*FROM country";
			     $run=mysqli_query($conn,$sql);
			     while($row=$run->fetch_assoc()) 
			     {
			         // echo $row['country'];
			     
			     
				?>
			       <option value="<?php echo $row['c_id'] ?>"><?php echo $row['country_name'];}?></option><!--  ajax data -->


				</select>	
				<span class="error" id="err_country">Please Fill the Feild</span>	
			</div>	
			<div>
				<label>State</label>
				<select  name="state" id="state">
			       <option value="select">Select</option>		   
				</select>	
				<span class="error" id="err_state">Please Fill the Feild</span>	
			</div>	
			<div>
				<label>City</label>
				<input type="text" name="city" id="city" value="<?php echo $row['city']; ?>">
				<span class="error" id="err_city">Please Fill the Feild</span>
			</div>
			<div>
				<label>Pincode</label>
				<input type="text" name="pincode" id="pincode" value="<?php echo $row['pincode']; }?>">
				<span class="error" id="err_pincode">Please Fill the Feild</span>
				<span class="error" id="err_pincode_check">Please Enter Number in Pincode </span>
			</div>
			<div class="btn">
				<input type="submit" name="submit" value="Submit" id="btn">
			</div>
		</form>
	</div>
	<div id="success"></div>
<script type="text/javascript">

		$(document).ready(function() {

		  $("#form").submit(function(){ 
		  $("#err_fname,#err_lname,#err_email,#err_gender,#err_country,#err_state,#err_mobile_no,#err_addr1,#err_addr2,#err_city,#err_pincode,#err_fname_check,#err_lname_check,#pattern_err_email,#err_pincode_check,#err_mobile_no_check,#err_email_exist").css("display", "none");
		 
		  var fname=$("#fname").val();
		  var lname=$("#lname").val();
		  var email=$("#email").val();
		  // var male=$("#male").val();
    //       var female=$("#female").val();
          var gender =$('input[name=gender]:radio:checked').val()          
          var mobile=$("#mobile_no").val();
          var address1=$("#addr1").val();
          var address2=$("#addr2").val();
          var country = $('#country').val();
          var state = $('#state').val();
          var city=$("#city").val();
          var pincode=$("#pincode").val();
          var status = true;  //check values not empty only post ajax

         // alert(gender)
          //pattern check

          var name_pattern = /^[a-zA-Z]+$/;               //var regName = /^[a-zA-Z]+ [a-zA-Z]+$/;
		  var name_pattern1= /^[a-zA-Z]+ [a-zA-Z]+$/;
		  var email_pattern = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/; 

        //first name

        if (fname=="")
         {
         	$("#err_fname").css("display", "block");
         	status = false;
         
         }
     
         else if (name_pattern.test(fname) || name_pattern1.test(fname))
         {

         }
         else
         {
         	$("#err_fname_check").css("display", "block");

         }


         //last name

         
        if (lname=="")
         {
         	$("#err_lname").css("display", "block");  
         	status = false;    
         }

         else if (name_pattern.test(lname) || name_pattern1.test(lname))
         {

         }
         else
         {
         	$("#err_lname_check").css("display", "block");
         	status = false;

         }
        

         //email

	// $("#err_email").css("display", "none");

   //           if(pattern.test(email))
			// {
			//     	$("#pattern_err_email").css("display", "none");
			// }
			// else
			// {
			//         $("#pattern_err_email").css("display", "block");	
			// } //pattern check
         
        
        if (email=="")
         {
         
            $("#err_email").css("display", "block");
            status = false;
         	   
         } //empty check
         // else if(email_pattern.test(email))
         // {

         // }
         // else
         // {
         // 	$("#pattern_err_email").css("display", "block");	
         // }

         //Gender 

         
        // if ($('#male').prop("checked") == true || $('#female').prop("checked") == true)
        if(gender===undefined || gender===null)
        // if(gender!=="")
         {
         	// $("#err_gender").css("display", "none");
         	$("#err_gender").css("display", "block");
         	status = false;
         	      
         }
         else
         {
         	// $("#err_gender").css("display", "block");
         	// return false;
         }

         //mobile number

        if (mobile=="")
         {
         	$("#err_mobile_no").css("display", "block");
         	status = false;
         }
         else
         {
               
       	 }
         // else if(isNaN(pincode))
         // {
         	
         // 	$("#err_mobile_no_check").css("display", "block");

         // }

         //address 1

        
        if (address1!=="")
         {
         	// $("#err_addr1").css("display", "none");
         	
         
         }
         else
         {
         	$("#err_addr1").css("display", "block");
         	status = false;
         	// return false;

         }

         //address 2

        
        if (address2!=="")
         {
         	// $("#err_addr2").css("display", "none");
         	
         
         }
         else
         {
         	$("#err_addr2").css("display", "block");
         	status = false;
         	// return false;

         }

         //country

            
			  if(country == "select")
			  {
			   
			    $("#err_country").css("display", "block");
			    status = false;
			  }
			  else
			  {
                 // $("#err_country").css("display", "none");
			  }

        //state

			  if(state == "select")
			  {
			   
			    $("#err_state").css("display", "block");
			    status = false;
			  }
			  else
			  {
                 // $("#err_state").css("display", "none");
			  }

        //city

        
        if (city!=="")
         {
         	// $("#err_city").css("display", "none");
         	
         
         }
         else
         {
         	$("#err_city").css("display", "block");
         	status = false;
         	// return false;

         }

         //pincode

        
        if (pincode=="")
         {
         	$("#err_pincode").css("display", "block");    
         }
         else if(isNaN(pincode))
         {
         	$("#err_pincode_check").css("display", "block");
         	status = false;

         }
         else
         {
         		
         }

         // return false;

       //ajax data 

        var form_data={fname,lname,email,gender,mobile,address1,address2,country,state,city,pincode};
        // var form_data = new FormData($("#form")[0]);
    if (status) 
     
     {   
	       $.ajax({

			  type: "POST",
			  url: "postdata.php",
			  data: {values: form_data},
			  dataType: "json",
			  success: function (response) { 
	                    // $('#success').html(response);
	                    // alert(form_data);
	                    if (response.status==1)  //get from json object from postdata page using json_encode
	                    { 
	                    	// $("#err_email_exist").css("display", "block");  	                    
                            $('#success').html(response.message);
                             setTimeout(function(){
                             window.location.href = 'index.php';
                              }, 1000);

	                    } //if
	                    if (response.status==2)  //get from json object from postdata page using json_encode
	                    { 
	                    	// $("#err_email_exist").css("display", "block");  
                            $('#success').html(response.message);

	                    } //if
	                    if (response.status==3)  //get from json object from postdata page using json_encode
	                    { 
	                    	$("#err_email_exist").css("display", "block");  
	                    	$("input[name=email]").focus()
                            $('#err_email_exist').html(response.message);

	                    } //if

	                }//response function

			  });	//ajax	
      }
     // alert("submit");
        
	

     return false;

     

	

	});	//submit function
		

		  });//ready	
      

      //ajax data post


	$(document).ready(function() {

		  $("#country").change(function(){ 
		  var value = $(this).val();  // #con also this
		  			// data = 'country='+value;
		  			// alert(value);
		  $.ajax({
		  type: "POST",
		  url: "statedata.php",
		  data: {country:value},
		  dataType: "text",
		  success: function (response) { 
                    $('#state').html(response);
                }
		  });	//ajax		 
		  }); //onchange
	}); //ready function
			  
</script>

</body>
</html>