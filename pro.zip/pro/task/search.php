<?php 
require_once('conn.php');

// echo'<td>'.$_POST['searchinfo'].'</td>';

    $condition=$_POST['searchinfo'];
    // $sql="SELECT * FROM personal_detail";
    $sql="SELECT * FROM  personal_detail WHERE CONCAT(first_name,last_name,email,gender,mobile_no,addr1,addr2,country,state,city,pincode)VALUES('$fname','$lname','$email','$gender','$mobile','$address1','$address2','$country','$state','$city','$pincode') LIKE '%".$condition."%'";
    $run=$conn->query($sql);
    
   
 ?>