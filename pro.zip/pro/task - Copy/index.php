<?php
require_once('conn.php');
// $sql="SELECT * FROM personal_detail";
// $sql="SELECT * from personal_detail inner join country ON personal_detail.country=country.C_id ";
$sql="SELECT * from personal_detail inner join country ON personal_detail.country=country.C_id INNER join state on personal_detail.state=state.s_id";
// $sql="SELECT * from personal_detail inner join state ON personal_detail.state=state.s_id";
$run=mysqli_query($conn,$sql);
?>
<!DOCTYPE html>
<html>
<head>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<title>Home</title>
	<style type="text/css">
		*
		{
			margin: 0;
			padding: 0;
		}
		.head
		{
			height: 50px;
			background-color: #3492eb;
		}
		.pd_div
		{
		    background-color: #e7e7e7;
		    height: 50px;
		    display: flex;
		    justify-content: space-between;
		    align-content: center;
		    align-items: center;	   
		}
		.add_user
		{
			 text-decoration: none;
			 background-color: #14c71a;
			 padding: 8px 20px;
			 margin: 0px 20px;
			 color: white;
			 border-radius: 20px;
		}
		.heading
		{
			margin-left: 20px;
			font-size: 24px;
			font-weight: bold;
		}
		.filter_search
		{
            height: 80px;
            /*background-color: #abdc;*/
            display: flex;
            align-items: center;
            float: right;
            margin-right: 20px;


            /*justify-content: space-between;*/

		}
		.search
		{
			outline: none;
			padding: 5px 8px;
		}
		.clear
		{
			clear: both;
			display: flex;
			justify-content: center;
		}
		#list 
		{
		  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
		  border-collapse: collapse;
		  width: 100%;
        }

        #list td, #list th 
        {
		  border: 1px solid #ddd;
		  padding: 8px;
		  text-align: center;
        }

        #list tr:nth-child(even)
        {
        	background-color: #f2f2f2;
        }

		#list tr:hover 
		{
			background-color: #ddd;
			cursor: pointer;
		}

		#list th 
		{
		  padding-top: 12px;
		  padding-bottom: 12px;
		  text-align: left;
		  background-color: #4CAF50;
		  color: white;
		}

	</style>
</head>
<body>
	<div class="head">
		
	</div>

	<div class="pd_div">
		<p class="heading">Personal Details</p>
		<a class="add_user" href="personal_detail.php">Add User</a>
	</div>

	<div class="filter_search">
		<div class="search_right">
			<input type="text" class="search" id="search_input" name="" placeholder="Search">
			<!-- <button>Search</button> -->
	     </div>
	</div>

<div class="clear">
	

<table id="list">
	<thead>
  <tr>
				<th><input type="checkbox" name=""></th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>email</th>
				<th>Gender</th>
				<th>Mobile Number</th>
				<th>Adress 1</th>
				<th>Adress 2</th>
				<th>Country</th>
				<th>State</th>
				<th>City</th>
				<th>Pincode</th>
				<th>Edit</th>
				<th>Delete</th>
			</tr>
			</thead>
   <tbody id="tabledata">
	 <?php
	 foreach($run as $row) 
	  {
	  ?>
    <tr>
    	<td><input type="checkbox" name=""></td>
	    <td><?php echo $row['first_name']; ?></td>
   		<td><?php echo $row['last_name']; ?></td>
   		<td><?php echo $row['email']; ?></td>  	
   		<td><?php echo $row['gender']; ?></td>
   		<td><?php echo $row['mobile_no']; ?></td>
   		<td><?php echo $row['addr1']; ?></td> 
   		<td><?php echo $row['addr2']; ?></td>
   		<td><?php echo $row['country_name']; ?></td>
   		<td><?php echo $row['state_name']; ?></td> 
   		<td><?php echo $row['city']; ?></td>
   		<td><?php echo $row['pincode']; ?></td>
   		<td><a href="personal_detail.php?id=<?php echo $row['id']; ?>"><img src="edit.png" height="20px" width="20px"></a></td>
   		<td><img src="delete.png" height="20px" width="20px"></td>
    </tr>	
	<?php } ?>
	</tbody>
</table> 
 </div> 
<script type="text/javascript">
	$(document).ready(function(){
    $("#search_input").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#tabledata tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
	    });
	  });
	});
</script>
</body>
</html>