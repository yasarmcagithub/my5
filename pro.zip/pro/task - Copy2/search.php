<?php 
require_once('conn.php');

// echo'<td>'.$_POST['searchinfo'].'</td>';
    if (isset($_POST['searchinfo'])) 
    {
    $condition=$_POST['searchinfo'];
    // $sql="SELECT * FROM personal_detail";
    $sql="SELECT * FROM  personal_detail WHERE CONCAT(first_name,last_name,email,gender,mobile_no,addr1,addr2,country,state,city,pincode)LIKE '%$condition%'";
    // echo $sql; //check query
    $run=$conn->query($sql);

    foreach ($run as $row) 
    {
    	echo "<tr>";
    	echo "<td><input type='checkbox'></td>";
    	echo "<td>".$row['first_name']."</td>";
    	echo "<td>".$row['last_name']."</td>";
    	echo "<td>".$row['email']."</td>";
    	echo "<td>".$row['gender']."</td>";
    	echo "<td>".$row['mobile_no']."</td>";
    	echo "<td>".$row['addr1']."</td>";
    	echo "<td>".$row['addr2']."</td>";
    	echo "<td>".$row['country']."</td>";
    	echo "<td>".$row['state']."</td>";
    	echo "<td>".$row['city']."</td>";
    	echo "<td>".$row['pincode']."</td>";
    	echo "<td><a href='personal_detail.php' ><img src='edit.png' height='20px' width='20px'></a></td>";
    	echo "<td><img src='delete.png' height='20px' width='20px'></td>";
    	echo "</tr>";
    } 

    }//if end
   
 ?>